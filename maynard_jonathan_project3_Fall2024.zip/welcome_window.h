#ifndef WELCOME_WINDOW_H
#define WELCOME_WINDOW_H

#include <string>

bool showWelcomeWindow(std::string &playerName);

#endif
