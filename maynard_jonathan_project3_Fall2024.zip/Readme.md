Name: Jonathan Maynard
Section: #11818
UFL email: jonathan.maynard@ufl.edu
System: Windows 11
Compiler: g++
SFML version: SFML 2.5.1
IDE: I'm using CLion
Other notes: This works perfectly on my computer. All of the source files go into the root folder of the project.